#include"TwoHit.h"
#include"MissilePU.h"



TwoHit::~TwoHit()
{
    spriteSheetTexture = NULL;
    cout<<"Enemy Deallocated"<<endl;
    delete ObjRectangle;
    ObjRectangle = NULL;
}

TwoHit::TwoHit(LTexture* image, float x, float y,int frame):Enemy(image, x, y, frame)
{
    Type = "OneHit";

    ObjRectangle = new SDL_Rect;

    ChangeInX = x;
    Row = x;                    // only an integer between 0 and 10
    Column = y;                 // only an integer between 0 and 4

    rotation = 180.0;
    health = 2;
    friction = 0.85f;
    //Frame 0
    spriteClips[ 0 ].x = 156.5;
    spriteClips[ 0 ].y = 171.25;
    spriteClips[ 0 ].w = 24.25;
    spriteClips[ 0 ].h = 24.25;

    //Frame 1
    spriteClips[ 1 ].x = 180.75;
    spriteClips[ 1 ].y = 171.25;
    spriteClips[ 1 ].w = 24.25;
    spriteClips[ 1 ].h = 24.25;
    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
    EnemyNumber = (frame%8);
        if (Column <= 7)
    {
        this->x = -10;
    }
    if (Column > 7)
    {
        this->x = 1000;
    }

    this->y = -25;
    ObjRectangle->x = x;
    ObjRectangle->y = y;
    ObjRectangle->h = height;
    ObjRectangle->w = width;



}


void TwoHit::Move(int SCREEN_HEIGHT)
{
    ObjTime ++;
    if (y > SCREEN_HEIGHT+96)
    {
        SetAlive(false);
    }
    if (ObjTime <= 50)
    {
        if (Column >7)
        {
            x-= exp((ObjTime-34)/10.0);
        }
        else if (Column <=7)
        {
            x+= exp((ObjTime-34)/10.0);
        }
        y += 4*(sqrt(8*ObjTime)/5) ;
    }

    if (ObjTime > 50 && ObjTime <= 95)
    {
        if (Column >7)
        {
            x -= 1.9+ ((Column-7.0)/1.0);
        }
        else if (Column <=7)
        {
            x += 2.30+ (Column/1.0);
        }

        y += 25*(sin((ObjTime+130)*3.14/(180))) + (Row);
    }
    if (ObjTime>= 1000 - 150*(Row) + 50*(Column%8))
    {
        if (Column >7)
        {
            x-= (10*cos(ObjTime/5));
        }
        else if (Column <=7)
        {
            x+= (10*cos(ObjTime/5));
        }

        y+= 10;
        if (ObjTime%10 == 0)
        {
            FireON = true;
        }
        else
        {
            FireON = false;
        }
        //y+= (10*sin(ObjTime/50));
    }
    rotation = 180 +3.0*(x-ChangeInX+1);
    ChangeInX = x;
//    ObjTime ++;
//    if (y > SCREEN_HEIGHT+96)
//    {
//        SetAlive(false);
//    }
//    if (ObjTime <= 30)
//    {
//        x += 1 ;
//        y += sqrt(4*2*ObjTime)/5;
//    }
//    if (ObjTime > 30 && ObjTime <=  300)
//    {
//        x += 1 + EnemyNumber ;
//        y += 4*(sin(ObjTime*3.14/(180)));
//    }
//---------------------------------------------//
//    if (ObjTime<50) // value 280 works
//    {
//    x+= 1;
//    y+= (x*x)/10000;
//    }
//    if (ObjTime>500 && ObjTime<300) // value 280 works
//    {
//    x+= 1;
//    y-= (x*x)/1000;
//    }
//    if (ObjTime>=300)
//    {
//    x+= (10*cos(ObjTime/5));
//    y+= (10*sin(ObjTime/50));
//    }

}

void TwoHit::MoveL(int direction)
{

    if(direction==2) //Left
    {
        speedx = -5;
        //x+=speedx;
    }

    if(direction==3) //Right
    {
        speedx = 5;
        //x+=speedx;
    }

}

void TwoHit::Move()
{
    speedx = speedx * friction;
    //x = x + speedx;
}


void TwoHit::Render(long int& frame, SDL_Renderer* gRenderer)
{
    ObjRectangle->x = x;
    ObjRectangle->y = y;


    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame/10 % 2 ], rotation, NULL, SDL_FLIP_VERTICAL, gRenderer );

}

