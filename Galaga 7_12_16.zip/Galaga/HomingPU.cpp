#include"HomingPU.h"



HomingPU::~HomingPU()
{
    spriteSheetTexture = NULL;
    cout<<"Enemy Deallocated"<<endl;
    delete ObjRectangle;
    ObjRectangle = NULL;
}

HomingPU::HomingPU(LTexture* image, float x, float y,int frame):PowerUP(image, x, y, frame)
{
    Type = "HomingPU";

    ObjRectangle = new SDL_Rect;

    rotation = 0.0;
    health = 1000000;
    friction = 0.85f;
    //Frame 0
    spriteClips[ 0 ].x = 246.0;
    spriteClips[ 0 ].y = 318.0;
    spriteClips[ 0 ].w = 15;
    spriteClips[ 0 ].h = 15;
    EnemyNumber = frame;
    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
    ObjRectangle->x = x;
    ObjRectangle->y = y;
    ObjRectangle->h = height;
    ObjRectangle->w = width;



}


void HomingPU::Move(int SCREEN_HEIGHT)
{
    ObjTime ++;

    //EnemyTicks ++;
    if (y > SCREEN_HEIGHT+96)
    {
        SetAlive(false);
    }
    y+=2;


}

void HomingPU::MoveL(int direction)
{

    if(direction==2) //Left
    {
        speedx = -5;
        //x+=speedx;
    }

    if(direction==3) //Right
    {
        speedx = 5;
        //x+=speedx;
    }

}

void HomingPU::Move()
{
    speedx = speedx * friction;
    //x = x + speedx;
}


void HomingPU::Render(long int& frame, SDL_Renderer* gRenderer)
{
    ObjRectangle->x = x;
    ObjRectangle->y = y;


    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ 0], rotation, NULL, SDL_FLIP_NONE, gRenderer );

}

