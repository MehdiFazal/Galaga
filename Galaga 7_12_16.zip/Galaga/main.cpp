#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "LTexture.h"
#include "Queue.h"
#include "Unit.h"
#include "OneHit.h"
#include "TwoHit.h"
#include "Bullet.h"
#include "Explosion.h"
#include "Enemy.h"
#include "PowerUP.h"
#include "MissilePU.h"
#include "Player.h"
#include "Missile.h"
#include "MachineGun.h"
#include "Homing.h"
#include "Hunter.h"
#include "ExplosionE.h"
#include "ExplosionP.h"
#include "ExplosionH.h"
#include "GunPU.h"
#include "LifePU.h"
#include "HomingPU.h"


//Pre defined screen width and height
const int SCREEN_WIDTH = 1024;
const int SCREEN_HEIGHT = 768;

bool init();

bool loadMedia();

void close();

SDL_Window* gWindow = NULL;

SDL_Renderer* gRenderer = NULL;

LTexture gSpriteSheetTexture;

bool init();
bool loadMedia();
void close();

int main( int argc, char* args[] )
{
	//Start up SDL and create window
	if( !init() )
	{
		printf( "Failed to initialize!\n" );
	}
	else
	{
		//Load media
		if( !loadMedia() )
		{
			printf( "Failed to load media!\n" );
		}
		else
		{
		    /*
		    Screen* screen = NULL;
		    int screentype = 0;
		    while()
            switch(screentype)
            {
            case 0:
                screen = New SplashScreen;
                screen.play();
                screentype = 1;
            }*/
			bool quit = false;                      //Main loop flag
			unsigned long int bulletDelay = 0;

			SDL_Event e;                            //Event handler

			long int frame = 0;                     //Current animation frame
			/* initialize random seed: */
            srand (time(NULL));

            /* generate secret number between 1 and 10: */
            int random = 0;
            Queue EnemyPlanes;
            bool BulletCreated = false;
            float row = 0.0;
            float column = 0.0;
			Player* plane = new Player(&gSpriteSheetTexture, (float)SCREEN_WIDTH/2, (float)SCREEN_HEIGHT/2,frame);
            GunPU* GunPower = new GunPU(&gSpriteSheetTexture, 300, 300, frame);
            EnemyPlanes.Enqueue(GunPower);
            //HomingPU* GunPower2 = new HomingPU(&gSpriteSheetTexture, row, column, frame);
            //EnemyPlanes.Enqueue(GunPower2);
            MissilePU* GunPower3 = new MissilePU(&gSpriteSheetTexture, 300, 300, frame);
            EnemyPlanes.Enqueue(GunPower3);
            LifePU* GunPower4 = new LifePU(&gSpriteSheetTexture, 300, 300, frame);
            EnemyPlanes.Enqueue(GunPower4);
            //ExplosionH* Expo = new ExplosionH(&gSpriteSheetTexture, 400, 400, 45.0);
            //EnemyPlanes.Enqueue(plane);




			while( !quit )                          //While application is running
			{
			    if(frame%10 == 0 && frame<400)
                {
                    //MachineGun* bullet1 = new MachineGun(&gSpriteSheetTexture, 400.0, 30.0, -10.0);
                    //EnemyPlanes.Enqueue(bullet1);
                    MachineGun* bullet2 = new MachineGun(&gSpriteSheetTexture, 400.0, 30.0, 10.0);
                    EnemyPlanes.Enqueue(bullet2);
                    MachineGun* bullet3 = new MachineGun(&gSpriteSheetTexture, 400.0, 30.0, 20.0);
                    EnemyPlanes.Enqueue(bullet3);
                    //MachineGun* bullet4 = new MachineGun(&gSpriteSheetTexture, 400.0, 30.0, -20.0);
                    //EnemyPlanes.Enqueue(bullet4);
                    random = rand() % SCREEN_WIDTH;
                    if (int(row)%2 == 0.0)
                    {

                        TwoHit* SingleEnemy = new TwoHit(&gSpriteSheetTexture, row, column, frame);
                        TwoHit* SingleEnemy5 = new TwoHit(&gSpriteSheetTexture, row, column+8.0, frame);
                        SingleEnemy->SetTarget(plane);
                        SingleEnemy5->SetTarget(plane);
                        EnemyPlanes.Enqueue(SingleEnemy);
                        EnemyPlanes.Enqueue(SingleEnemy5);
//                        Homing* Misl = new Homing(&gSpriteSheetTexture, 400.0, 30.0, 0.0);
//                        Misl->SetTarget(plane);
//                        EnemyPlanes.Enqueue(Misl);
                    }
                    else
                    {
                        Hunter* SingleEnemy2 = new Hunter(&gSpriteSheetTexture, row, column, 0.0);
                        Hunter* SingleEnemy7 = new Hunter(&gSpriteSheetTexture, row, column + 8.0, 0.0);
                        SingleEnemy2->SetTarget(plane);
                        SingleEnemy7->SetTarget(plane);
                        EnemyPlanes.Enqueue(SingleEnemy2);
                        EnemyPlanes.Enqueue(SingleEnemy7);

                    }

                    column++;
                    if(column == 8.0)
                    {
                        column = 0.0;
                        row ++;
                    }

                }

				while( SDL_PollEvent( &e ) != 0 )   //Handle events on queue
				{


					//User requests quit
					if( e.type == SDL_QUIT )
					{
						quit = true;
					}


				}

				const Uint8* currentKeyStates = SDL_GetKeyboardState( NULL );

                    if(currentKeyStates[ SDL_SCANCODE_RIGHT ])
                    {
                        plane->Move(RIGHT);
                    }

                    if(currentKeyStates[ SDL_SCANCODE_LEFT ])
                    {
                        plane->Move(LEFT);
                    }

                    if(currentKeyStates[ SDL_SCANCODE_UP ])
                    {
                        plane->Move(UP);
                    }

                    if(currentKeyStates[ SDL_SCANCODE_DOWN ])
                    {
                        plane->Move(DOWN);
                    }
                    if(currentKeyStates[ SDL_SCANCODE_SPACE ])
                    {
                        if (bulletDelay > 10)
                        {
                            MachineGun* Gun = new MachineGun(&gSpriteSheetTexture, plane->getX()-6.8, plane->getY(), 180.0);
                            EnemyPlanes.Enqueue(Gun);

                            bulletDelay = 0;
//                            Bullet* bullet2 = new Bullet(&gSpriteSheetTexture, 195, 600,'P');
//                            EnemyPlanes.Enqueue(bullet2);
                            //BulletCreated = true;
//                            //EnemyPlanes.FireClean();
                        }
                    }

				SDL_SetRenderDrawColor( gRenderer, 0, 0, 0, 0xFF );    //Clear screen
				SDL_RenderClear( gRenderer );
				EnemyPlanes.update(frame, gRenderer);
				EnemyPlanes.collision(&gSpriteSheetTexture, plane);

                //EnemyPlanes.Move(SCREEN_HEIGHT);
                plane->Render(frame, gRenderer);
                plane->Move();
                //EnemyPlanes.Clean();
				SDL_RenderPresent( gRenderer );     //Update screen
                BulletCreated = false;
                ++frame;
                ++bulletDelay;
			}
		}
	}

	close();

	return 0;
}

bool init()
{
	//Initialization flag
	bool success = true;

	//Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		//Create window
		gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
		if( gWindow == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}
		else
		{
			//Create renderer for window
			gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
            if( gRenderer == NULL )
            {
                printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
                success = false;
            }
			else
			{
				//Initialize renderer color
				SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_mage Error: %s\n", IMG_GetError() );
					success = false;
				}
			}
		}
	}

	return success;
}

bool loadMedia()
{
	//Loading success flag
	bool success = true;

	//Load sprite sheet texture
	if( !gSpriteSheetTexture.LoadFromFile( "Images/galaga.png", gRenderer  ) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}

	return success;
}

void close()
{
	//Free loaded images
	gSpriteSheetTexture.Free();

	//Destroy window
	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;

	//Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}
