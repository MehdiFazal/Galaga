#include"Bullet.h"

Bullet::Bullet(LTexture* image, float x, float y,int frame):Unit(image, x, y, frame)
{

}
Bullet::~Bullet()
{
    spriteSheetTexture = NULL;
    cout<<"Bullet Deallocated"<<endl;
}
