#pragma once
#include "SDL.h"
#include "LTexture.h"


class Screen
{
protected:
    float x;
    float y;
    bool Alive;
    int alpha;
    int ScreenTime;
    LTexture* spriteSheetTexture;
    SDL_Rect spriteClip;

public:
    ~Screen();
    Screen(LTexture* image, float x, float y );
    virtual void Move();
    virtual void Transition();
    virtual void Render(SDL_Renderer* gRenderer);
    bool GetAlive();


};
