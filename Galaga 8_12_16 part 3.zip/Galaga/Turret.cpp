#include"Turret.h"

Turret::Turret(LTexture* image,float x,float y, int frame))
{

}

Turret::~Turret()
{
    //cout<<"\nTurret Destructor Called";
}

