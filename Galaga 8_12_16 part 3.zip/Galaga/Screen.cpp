#include"Screen.h"
#include "SDL.h"
#include "LTexture.h"


Screen::Screen(LTexture* image, float x, float y)
{
    ScreenTime = 0;
    Alive = true;
    spriteSheetTexture = image;
    this->x = x;
    this->y = y;
    spriteClip.x = this->x;
    spriteClip.y = this->y;
    spriteClip.w = 1024;
    spriteClip.h = 768;
}

Screen::~Screen()
{
    spriteSheetTexture = NULL;
}

bool Screen::GetAlive()
{
    return Alive;
}

void Screen::Move()
{

}

void Screen::Render(SDL_Renderer* gRenderer)
{

}

void Screen::Transition()
{

}

