#pragma once
#include"Enemy.h"


class Turret: public Enemy
{
public:
    ~Turret();
    Turret(LTexture* , float, float, int);
    //virtual void Move(float);
};
