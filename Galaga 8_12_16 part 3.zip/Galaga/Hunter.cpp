#include"Hunter.h"
#include"MissilePU.h"



Hunter::~Hunter()
{
    spriteSheetTexture = NULL;
    delete ObjRectangle;
    ObjRectangle = NULL;
}

Hunter::Hunter(LTexture* image, float x, float y,int frame):Enemy(image, x, y, frame)
{
    Type = "Hunter";

    ObjRectangle = new SDL_Rect;

    ChangeInX = x;
    Row = x;                    // only an integer between 0 and 10
    Column = y;                 // only an integer between 0 and 4

    rotation = 180.0;
    health = 2;
    friction = 0.85f;
    //Frame 0
    spriteClips[ 0 ].x = 156.0;
    spriteClips[ 0 ].y = 315.0;
    spriteClips[ 0 ].w = 22.0;
    spriteClips[ 0 ].h = 24.0;

    //Frame 1
    spriteClips[ 1 ].x = 178.0;
    spriteClips[ 1 ].y = 315.0;
    spriteClips[ 1 ].w = 22.0;
    spriteClips[ 1 ].h = 24.0;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
    //EnemyNumber = (frame%8);
        if (Column <= 7)
    {
        this->x = -10;
    }
    if (Column > 7)
    {
        this->x = 1000;
    }

    this->y = -25;
    //ObjTime = 800.0;
    ObjRectangle->x = x;
    ObjRectangle->y = y;
    ObjRectangle->h = height+15;
    ObjRectangle->w = width +15;
    health = 1;


}


void Hunter::Move(int SCREEN_HEIGHT)
{
    ObjTime ++;
//-----------------------------------------------------------------------//
    if (y > SCREEN_HEIGHT+96)
    {
        SetAlive(false);
    }
//-----------------------------------------------------------------------//

    if (ObjTime <= 50)
    {
        if (Column >7)
        {
            x-= exp((ObjTime-34)/10.0);
        }
        else if (Column <=7)
        {
            x+= exp((ObjTime-34)/10.0);
        }
        y += 4*(sqrt(8*ObjTime)/5) ;

    }
//-----------------------------------------------------------------------//

    if (ObjTime > 50 && ObjTime <= 95)
    {
        if (Column >7)
        {
            x -= 1.9+ ((Column-7.0)/1.0);
        }
        else if (Column <=7)
        {
            x += 2.30+ (Column/1.0);
        }

        y += 25*(sin((ObjTime+130)*3.14/(180))) + (Row);

    }
//-----------------------------------------------------------------------//
    if (ObjTime< 1000 - 150*(Row) + 50*(Column%8))
    {
        rotation =  - 3.0*(x-ChangeInX+1) ;
        ChangeInX = x;
    }

//-----------------------------------------------------------------------//


    if (ObjTime>= 1000 - 150*(Row) + 50*(Column%8))
    {

        if (ObjTime < 1000 - 150*(Row) + 50*(Column%8)+70)
        {
            ConsTargetX = target->getX();
            ConsTargetY = target->getY();
            if (ObjTime%10 == 0)
            {
                FireON = true;
            }
            else
            {
                FireON = false;
            }
        }
        if (y<ConsTargetY)
        {
            if (ConsTargetX>x)
            {
                rotation = 90-  180*atan((y-ConsTargetY)/(x-ConsTargetX))/3.1416 ;
            }
            else
            {
                rotation =270-  180*atan((y-ConsTargetY)/(x-ConsTargetX))/3.1416 ;
            }
            speedx = 4.5*sin(rotation*3.1416/180);
            speedy = 2*cos(rotation*3.1416/180);
        }
        if (ObjTime > 1000 - 150*(Row) + 50*(Column%8) +200 )
        {
            speedx =0 ;
            speedy = 0;
        }

        y+=speedy;
        x+=speedx;


    }

}

void Hunter::MoveL(int direction)
{

}

void Hunter::Move()
{

}


void Hunter::Render(long int& frame, SDL_Renderer* gRenderer)
{
    ObjRectangle->x = x-5;
    ObjRectangle->y = y-5;
    SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );    //Clear screen
    SDL_RenderDrawRect(gRenderer, ObjRectangle );


    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame/10 % 2 ], 180-rotation, NULL, SDL_FLIP_NONE, gRenderer );

}




