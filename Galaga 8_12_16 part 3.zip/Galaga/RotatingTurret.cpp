#include"RotatingTurret.h"
#include <iostream>

RotatingTurret::RotatingTurret(LTexture* image, float x, float y, int frame):Turret(image, x, y, frame)
{
    spriteSheetTexture = image;

    //Frame 0
    spriteClips[ 0 ].x = 217;
    spriteClips[ 0 ].y = 280;
    spriteClips[ 0 ].w = 11;
    spriteClips[ 0 ].h = 11;

    this->x = x;
    this->y = y;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;

}

RotatingTurret::~RotatingTurret()
{

}

void RotatingTurret::Follow(float x, float y)
{
    int perp = x - this->x;
    int base = this->y - y;
    if (base != 0)
    {
        angle = atan2(perp,base) * (180 / 3.14159265) + 180;
    }
    else
    {
        angle = 90.0;
    }


}

void RotatingTurret::Move(float y)
{
    this->y = y;
}


void RotatingTurret::Render(long int& frame, SDL_Renderer* gRenderer)
{
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[frame % 1], angle, NULL, SDL_FLIP_VERTICAL, gRenderer );
}
