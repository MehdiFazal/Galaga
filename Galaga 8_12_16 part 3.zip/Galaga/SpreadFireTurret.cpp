#include "SpreadFireTurret.h"

SpreadFireTurret::SpreadFireTurret(LTexture* image, float x, float y, int frame):Turret(image, x, y, frame)
{
    spriteSheetTexture = image;

    //Frame 0
    spriteClips[ 0 ].x = 205;
    spriteClips[ 0 ].y = 280;
    spriteClips[ 0 ].w = 9;
    spriteClips[ 0 ].h = 9;

    this->x = x;
    this->y = y;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;

}

SpreadFireTurret::~SpreadFireTurret()
{

}

void SpreadFireTurret::Move(float y)
{
    this->y = y;
}


void SpreadFireTurret::Render(long int& frame, SDL_Renderer* gRenderer)
{
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[frame % 1], 0.0, NULL, SDL_FLIP_VERTICAL, gRenderer );
}

