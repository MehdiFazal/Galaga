#pragma once
#include "Turret.h"

class StraightTurret:public Turret
{
public:
    StraightTurret(LTexture*, float, float, int);
    ~StraightTurret();
    virtual void Render(long int& frame, SDL_Renderer* gRenderer);
};
