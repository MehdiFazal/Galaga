#include "Boss.h"

Boss::~Boss()
{
    delete Sturret;
    delete Rturret;
    delete SFturret;

}

Boss::Boss(LTexture* image, float x, float y, int frame):Enemy(image, x, y, frame)
{

    //Frame 0
    spriteClips[ 0 ].x = 183;
    spriteClips[ 0 ].y = 256;
    spriteClips[ 0 ].w = 31;
    spriteClips[ 0 ].h = 20;

    //Frame 1
    spriteClips[ 1 ].x = 217;
    spriteClips[ 1 ].y = 256;
    spriteClips[ 1 ].w = 31;
    spriteClips[ 1 ].h = 20;

    //Frame 2
    spriteClips[ 2 ].x = 250;
    spriteClips[ 2 ].y = 256;
    spriteClips[ 2 ].w = 31;
    spriteClips[ 2 ].h = 20;


    this->x = x;
    this->y = y;

    Sturret = new StraightTurret(image, this->x+65,this->y+17, 0);
    SFturret = new SpreadFireTurret(image, this->x+3,this->y+2, 0);
    Rturret = new RotatingTurret(image, this->x-57,this->y+17, 0);
}

void Boss::Move(int SCREEN_HEIGHT, int SCREEN_WIDTH, float px, float py)
{
    if (y<SCREEN_HEIGHT/5)
    {
        speedy = 2;
        y+=speedy;
        Sturret->Move(y+17);
        SFturret->Move(y+2);
        Rturret->Move(y+17);
    }

    Rturret->Follow(px,py);

}

//void Boss::dodge(float x, float y)
//{
//
//}

void Boss::Render(long int& frame, SDL_Renderer* gRenderer)
{
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame/3 % 3 ], 0.0, NULL, SDL_FLIP_VERTICAL, gRenderer );
    SFturret->Render(frame, gRenderer);

    Rturret->Render(frame, gRenderer);
    spriteSheetTexture->Render( x - width/2-60, y - height/2, &spriteClips[ frame/3 % 3 ], 0.0, NULL, SDL_FLIP_VERTICAL, gRenderer );

    Sturret->Render(frame, gRenderer);
    spriteSheetTexture->Render( x - width/2+60, y - height/2, &spriteClips[ frame/3 % 3 ], 0.0, NULL, SDL_FLIP_VERTICAL, gRenderer );

}
