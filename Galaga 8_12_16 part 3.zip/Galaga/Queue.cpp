#include"Queue.h"
#include<iostream>
#include"ExplosionE.h"
#include"Bullet.h"
#include"Player.h"
#include"SDL.h"
#include"Unit.h"
#include "ExplosionP.h"
#include "time.h"
#include "stdlib.h"
#include "Homing.h"
#include "MissilePU.h"
#include "GunPU.h"
#include "LifePU.h"
#include "HomingPU.h"
#include "PowerUP.h"

using namespace std;

Queue::Queue()
{
    head = NULL;
    tail = NULL;
}

Queue::~Queue()
{
    while(head != NULL)
    {
        Node* temp = head;
        head = head->next;
        cout<<"Deallocating value: "<<temp->unit<<endl;
        delete temp;
    }
}

void Queue::Enqueue(Unit* unit)
{
    if(head == NULL)
    {
        head = new Node;
        head->unit = unit;
        head->next = NULL;
        head->prev = NULL;
        tail = head;
        printf("head allocated");
    }
    else
    {
        tail->next = new Node;
        tail->next->unit = unit;
        tail->next->next = NULL;
        tail->next->prev = tail;
        tail = tail->next;
        printf("enemy allocated");
    }

}


void Queue::collision(LTexture* Texture, Player* plane)
{
    Node* PlayerPln = new Node;
    PlayerPln->unit = plane;
    Node* temp = NULL;
    Node* temp2 = NULL;
    temp = PlayerPln;
    while(temp != NULL)
    {
        temp2 = PlayerPln;
        while (temp2 != NULL)
        {
            srand (time(NULL));
            if (SDL_HasIntersection(temp->unit->GetRect(), temp2->unit->GetRect()) == SDL_TRUE)
            {
                if (((temp->unit->GetType() == "PMachineGun") || (temp->unit->GetType() == "PMissile") || (temp->unit->GetType() == "PHoming")) && ((temp2->unit->GetType() == "Hunter") || (temp2->unit->GetType() == "OneHit") || (temp2->unit->GetType() == "TwoHit") || (temp2->unit->GetType() == "EMachineGun") || (temp2->unit->GetType() == "EHoming") || (temp2->unit->GetType() == "EMissile")   ))
                {
                    int random = rand()%10;
                    printf("------------------------");
                    std::cout<<random;
                    temp2->unit->HealthLost();
                    temp->unit->HealthLost();
                    if (temp2->unit->getHealth()==0)
                    {
                        if (random > 8)
                        {
                            int random2 = rand()%3;
                            printf("------------------------");
                            std::cout<<random2;
                            PowerUP* Power = NULL;
                            if (random2 == 0)
                            {
                                Power = new HomingPU(Texture, temp2->unit->getX(), temp2->unit->getY(), 0.0);
                            }
                            else if (random2 == 1)
                            {
                                Power = new LifePU(Texture, temp2->unit->getX(), temp2->unit->getY(), 0.0);
                            }
                            else if (random2 == 2)
                            {
                                Power = new GunPU(Texture, temp2->unit->getX(), temp2->unit->getY(), 0.0);
                            }
                            else if (random2 == 3)
                            {
                                Power = new MissilePU(Texture, temp2->unit->getX(), temp2->unit->getY(), 0.0);
                            }
                            this->Enqueue(Power);

                        }
                        ExplosionE* explode = new ExplosionE(Texture, temp2->unit->getX()-10, temp2->unit->getY()-10, 0.0);
                        this->Enqueue(explode);
                    }
                }
                else if ((temp->unit->GetType() == "Player") && ((temp2->unit->GetType() == "EMachineGun") || (temp2->unit->GetType() == "EMissile") || (temp2->unit->GetType() == "EHoming")))
                {
                    temp2->unit->HealthLost();
                    temp->unit->HealthLost();
                    if (temp2->unit->getHealth()==0)
                    {
                        ExplosionP* explode = new ExplosionP(Texture, temp->unit->getX(), temp->unit->getY(), 0.0);
                        this->Enqueue(explode);
                    }
                }
                else if ((temp->unit->GetType() == "Player") && ((temp2->unit->GetType() == "GunPu") || (temp2->unit->GetType() == "EMissile") || (temp2->unit->GetType() == "EHoming")))
                {
                    temp2->unit->HealthLost();
                    temp->unit->HealthLost();
                    if (temp2->unit->getHealth()==0)
                    {
                        ExplosionP* explode = new ExplosionP(Texture, temp->unit->getX(), temp->unit->getY(), 0.0);
                        this->Enqueue(explode);
                    }
                }
            }
            if (temp->unit->getHealth() == 0)
            {
                temp->unit->SetAlive(false);
            }
            if (temp2->unit->getHealth() == 0)
            {
                temp2->unit->SetAlive(false);
            }
            if (temp2 == PlayerPln)
            {
                temp2 = NULL;
                temp2 = head;
            }
            else
            {
                temp2 = temp2->next;
            }

        }
        if (temp == PlayerPln)
        {
            temp = NULL;
            temp = head;
        }
        else
        {
            temp = temp->next;
        }
    }
    //delete PlayerPln;
    PlayerPln->unit = NULL;
    delete PlayerPln;

}


void Queue::update(long int& frame, SDL_Renderer* gRenderer)
{

    Node* temp = head;
    while (temp != NULL)
    {
        if (temp->unit->GetAlive() == false)
        {
//            CleanBreakout(temp);
            Node* temp2 = temp;
            temp = temp->next;
            if (temp2->prev != NULL)
            {
                temp2->prev->next = temp2->next;
            }
            else
            {
                head = temp;
            }
            if (temp2->next != NULL)
            {
                temp2->next->prev = temp2->prev;
            }
            else
            {
                tail = temp2->prev;
            }
            delete temp2;
            temp2 = NULL;
        }
        else
        {
            temp->unit->Render(frame, gRenderer);
            //if (temp->unit->GetType() == "Hunter")
            //{
                Unit* BulletPointer = temp->unit->Fire();
                if (BulletPointer != NULL)
                {
                    std::cout<<BulletPointer;
                    this->Enqueue(BulletPointer);
                }
                BulletPointer = NULL;
            //}
            temp->unit->Move(768);
            temp=temp->next;
        }



    }
}
