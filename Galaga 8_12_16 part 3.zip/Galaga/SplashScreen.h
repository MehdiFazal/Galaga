#pragma once
#include "Screen.h"
#include "SDL.h"
#include "LTexture.h"


class SplashScreen: public Screen
{
protected:
    int FadeNumber;
    int ShowTime;
public:
    SplashScreen(LTexture* image, float x, float y);
    ~SplashScreen();
    void Move();
    void Transition();
    void Render(SDL_Renderer*);

};
