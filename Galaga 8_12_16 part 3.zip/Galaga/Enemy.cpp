#include"Enemy.h"
#include"MachineGun.h"
#include"Bullet.h"
#include"Missile.h"
#include"Homing.h"

Enemy::Enemy(LTexture* image, float x, float y,int frame):Unit(image, x, y, frame)
{
    Type = "EPlane";
    FireON = false;
}
Enemy::~Enemy()
{

}

Unit* Enemy::Fire()
{
    if (FireON == true)
    {
        MachineGun* B = new MachineGun(spriteSheetTexture, x, y, 0.0);
        //Unit* B = new Homing(spriteSheetTexture, x, y, 45.0);
        B->SetTarget(this->target);
        return B;
    }
    else
    {
        return NULL;
    }
}
//=================================working code=============================//
//Unit* Enemy::Fire()
//{
//    if (FireON == true)
//    {
//        Unit* B = new Missile(spriteSheetTexture, x, y, 45.0);
//        return B;
//    }
//    else
//    {
//        return NULL;
//    }
//}
//===========================================================================//

