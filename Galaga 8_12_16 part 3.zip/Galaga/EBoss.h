#pragma once
#include<math.h>
#include<cmath>
#include"Enemy.h"
#include"Turret.h"
#include"ESpreadFire.h"
#include"EStraightFire.h"
#include"ERotating.h"

class EBoss:public Enemy
{
private:
    EStraightFire* Sturret;
    ESpreadFire* SFturret;
    ERotating* Rturret;
    float ConsTargetX;
    float ConsTargetY;
    enum ANIMATION_FRAMES {FLYING_FRAMES = 3};
    SDL_Rect spriteClips[ FLYING_FRAMES ];

public:
    EBoss(LTexture* image, float x, float y,int frame);
    ~EBoss();
    void Move(int SCREEN_HEIGHT);
    void Move();
    void MoveL(int direction);
    void Render(long int& frame, SDL_Renderer* gRenderer);
};
