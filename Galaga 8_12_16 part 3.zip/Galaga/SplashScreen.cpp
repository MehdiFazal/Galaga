#include "SplashScreen.h"
#include "SDL.h"

SplashScreen::SplashScreen(LTexture* image, float x, float y):Screen(image, x, y)
{
    alpha = 0;
    FadeNumber = 1;
    ShowTime = 100;
    ScreenTime =0 ;
}

SplashScreen::~SplashScreen()
{

}

void SplashScreen::Move()
{

}

void SplashScreen::Render(SDL_Renderer* gRenderer)
{
    spriteSheetTexture->Render( x , y , &spriteClip, 0.0 , NULL, SDL_FLIP_NONE, gRenderer );
    ScreenTime +=1;

}



void SplashScreen::Transition()
{

    float tempLimit = 255/FadeNumber;
    if (ScreenTime <= tempLimit)
    {
        alpha = alpha + FadeNumber;
        spriteSheetTexture->SetAlpha(alpha);
    }
    else if (ScreenTime >= ShowTime +2*tempLimit && ScreenTime < ShowTime + 3*tempLimit)
    {
        alpha = alpha - FadeNumber;
        spriteSheetTexture->SetAlpha(alpha);
    }
    if (alpha < 0)
    {
        Alive = false;
    }
}
