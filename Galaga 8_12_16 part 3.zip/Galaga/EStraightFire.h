#pragma once
#include<math.h>
#include<cmath>
#include"ETurret.h"

class EStraightFire:public ETurret
{
private:
    enum ANIMATION_FRAMES {FLYING_FRAMES = 1};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
public:
    EStraightFire(LTexture* image, float x, float y,int frame);
    ~EStraightFire();
    void Move(int SCREEN_HEIGHT);
    void Move();
    void MoveL(int direction);
    void Render(long int& frame, SDL_Renderer* gRenderer);
};
