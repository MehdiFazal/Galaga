#pragma once
#include<math.h>
#include<cmath>
#include"ETurret.h"

class ERotating:public ETurret
{
private:
    enum ANIMATION_FRAMES {FLYING_FRAMES = 1};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
public:
    ERotating(LTexture* image, float x, float y,int frame);
    ~ERotating();
    void Move(int SCREEN_HEIGHT);
    void Move();
    void MoveL(int direction);
    void Render(long int& frame, SDL_Renderer* gRenderer);
};
