#include "MachineGun.h"
#include "cmath"
#include "math.h"



MachineGun::~MachineGun()
{
    delete ObjRectangle;
    ObjRectangle = NULL;
}

MachineGun::MachineGun(LTexture* image, float x, float y, float angle):Bullet(image, x, y, angle)
{
    ObjRectangle = new SDL_Rect;
    if (angle<=90 && angle>=-90)
    {
        Type = "EMachineGun";
    }
    else
    {
        Type = "PMachineGun";
    }
    health = -1;
    spriteSheetTexture = image;
    rotation = angle;
    spriteClips[ 0 ].x = 360;
    spriteClips[ 0 ].y = 192;
    spriteClips[ 0 ].w = 12;
    spriteClips[ 0 ].h = 16;


    this->x = x;
    this->y = y;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;

    alive  = true;
    speedx = 25*sin(rotation*3.1416/180);
    speedy = 25*cos(rotation*3.1416/180);

    ObjRectangle->x = x +10 ;
    ObjRectangle->y = y +10;
    ObjRectangle->h = height+10;
    ObjRectangle->w = width+10;
    health = 1;


    //rotation = 360
    //speed


}

void MachineGun::Move(int SCREEN_HEIGHT)
{
    if (y <0 || y>SCREEN_HEIGHT+30 )
    {
        SetAlive(false);
    }

    y+=speedy;
    x+=speedx;
}

void MachineGun::Render(long int& frame, SDL_Renderer* gRenderer)
{
    ObjRectangle->x = x +10;
    ObjRectangle->y = y;
//    SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );    //Clear screen
//    SDL_RenderDrawRect(gRenderer, ObjRectangle );


    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ 0 ], 180-rotation, NULL, SDL_FLIP_NONE, gRenderer );
}
