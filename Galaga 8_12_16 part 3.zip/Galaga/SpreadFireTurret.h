#pragma once
#include "Turret.h"

class SpreadFireTurret:public Turret
{
public:
    SpreadFireTurret(LTexture*, float, float, int);
    ~SpreadFireTurret();
    virtual void Render(long int& frame, SDL_Renderer* gRenderer);
};
