#pragma once

#include"Enemy.h"

class ETurret: public Enemy
{
public:
    ETurret(LTexture* image, float x, float y,int frame);
    ~ETurret();

};
