#include"ETurret.h"
#include "Enemy.h"



ETurret::ETurret(LTexture* image, float x, float y,int frame):Enemy(image, x, y, frame)
{
    Type = "ETurret";

}
ETurret::~ETurret()
{
    spriteSheetTexture = NULL;
    cout<<"ETurret Deallocated"<<endl;
}
