#include"EBoss.h"
#include"MissilePU.h"



EBoss::~EBoss()
{
    spriteSheetTexture = NULL;
    delete ObjRectangle;
    ObjRectangle = NULL;
    delete Sturret;
    delete Rturret;
    delete SFturret;

}

EBoss::EBoss(LTexture* image, float x, float y,int frame):Enemy(image, x, y, frame)
{
    Type = "EBoss";
    Sturret = new EStraightFire(image, this->x+65,this->y+17, 0);
    SFturret = new ESpreadFire(image, this->x+3,this->y+2, 0);
    Rturret = new ERotating(image, this->x-57,this->y+17, 0);

    ObjRectangle = new SDL_Rect;

    ChangeInX = x;
    //Row = x;                    // only an integer between 0 and 10
    //Column = y;                 // only an integer between 0 and 4

    rotation = 0.0;
    health = 2;
    friction = 0.85f;
    //Frame 0
    spriteClips[ 0 ].x = 183;
    spriteClips[ 0 ].y = 256;
    spriteClips[ 0 ].w = 31;
    spriteClips[ 0 ].h = 20;

    //Frame 1
    spriteClips[ 1 ].x = 217;
    spriteClips[ 1 ].y = 256;
    spriteClips[ 1 ].w = 31;
    spriteClips[ 1 ].h = 20;

    //Frame 2
    spriteClips[ 2 ].x = 250;
    spriteClips[ 2 ].y = 256;
    spriteClips[ 2 ].w = 31;
    spriteClips[ 2 ].h = 20;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
    //EnemyNumber = (frame%8);
    this->x = x;
    this->y = y;
    //ObjTime = 800.0;
    ObjRectangle->x = x;
    ObjRectangle->y = y;
    ObjRectangle->h = height+15;
    ObjRectangle->w = width +15;


}


void EBoss::Move(int SCREEN_HEIGHT)
{
    if (Rturret->GetTarget() == NULL)
    {
        Rturret->SetTarget(this->GetTarget());
    }
    ObjTime ++;
    if (ObjTime > 200 && ObjTime < 400)
    {
            y+=2;

    }
    Sturret->Move(y+17);
    SFturret->Move(y+2);
    Rturret->Move(y+17);

    if (ObjTime >10 && ObjTime < 400)
    {
        if (ObjTime%20 == 0)
        {
            FireON = true;
        }
        else
        {
            FireON = false;
        }
    }
    else
    {
        FireON = false;
    }


}

void EBoss::MoveL(int direction)
{

}

void EBoss::Move()
{

}


void EBoss::Render(long int& frame, SDL_Renderer* gRenderer)
{
    ObjRectangle->x = x-5;
    ObjRectangle->y = y-5;
//    SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );    //Clear screen
//    SDL_RenderDrawRect(gRenderer, ObjRectangle );
    //spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame/10 % 2 ], 180-rotation, NULL, SDL_FLIP_NONE, gRenderer );
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame/3 % 3 ], 0.0, NULL, SDL_FLIP_VERTICAL, gRenderer );
    SFturret->Render(frame, gRenderer);

    Rturret->Render(frame, gRenderer);
    spriteSheetTexture->Render( x - width/2-60, y - height/2, &spriteClips[ frame/3 % 3 ], 0.0, NULL, SDL_FLIP_VERTICAL, gRenderer );

    Sturret->Render(frame, gRenderer);
    spriteSheetTexture->Render( x - width/2+60, y - height/2, &spriteClips[ frame/3 % 3 ], 0.0, NULL, SDL_FLIP_VERTICAL, gRenderer );

}




