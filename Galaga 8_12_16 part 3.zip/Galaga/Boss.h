#pragma once
#include "Enemy.h"
#include "Turret.h"
#include"StraightTurret.h"
#include"RotatingTurret.h"
#include"SpreadFireTurret.h"

class Boss:public Enemy
{
private:
    StraightTurret* Sturret;
    SpreadFireTurret* SFturret;
    RotatingTurret* Rturret;
    enum ANIMATION_FRAMES {FLYING_FRAMES = 3};
    SDL_Rect spriteClips[ FLYING_FRAMES ];

public:
    Boss(LTexture*, float, float, int);
    ~Boss();
    virtual void Move(int, int, float, float);
    virtual void Render(long int& frame, SDL_Renderer* gRenderer);
};
