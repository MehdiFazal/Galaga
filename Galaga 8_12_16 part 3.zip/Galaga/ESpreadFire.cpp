#include"ESpreadFire.h"

ESpreadFire::~ESpreadFire()
{
    spriteSheetTexture = NULL;
    cout<<"Enemy Deallocated"<<endl;
    delete ObjRectangle;
    ObjRectangle = NULL;
}

ESpreadFire::ESpreadFire(LTexture* image, float x, float y,int frame):ETurret(image, x, y, frame)
{
    Type = "ESpreadFire";
    ObjRectangle = new SDL_Rect;
    rotation = 0.0;
    health = 1000000;
    friction = 0.85f;

    spriteClips[ 0 ].x = 205;
    spriteClips[ 0 ].y = 280;
    spriteClips[ 0 ].w = 9;
    spriteClips[ 0 ].h = 9;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
    ObjRectangle->x = x;
    ObjRectangle->y = y;
    ObjRectangle->h = height;
    ObjRectangle->w = width;
}


void ESpreadFire::Move(int y)
{
    ObjTime ++;
    this->y = y;

}

void ESpreadFire::MoveL(int direction)
{

}

void ESpreadFire::Move()
{

}

void ESpreadFire::Render(long int& frame, SDL_Renderer* gRenderer)
{
    ObjRectangle->x = x;
    ObjRectangle->y = y;
    spriteSheetTexture->Render( x , y , &spriteClips[ 0], rotation, NULL, SDL_FLIP_NONE, gRenderer );

}

