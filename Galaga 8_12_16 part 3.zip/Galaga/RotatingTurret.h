#pragma once
#include "Turret.h"


class RotatingTurret:public Turret
{
private:
    float angle;
public:
    RotatingTurret(LTexture*, float, float, int);
    ~RotatingTurret();
    void Follow(float,float);
    void Render(long int&, SDL_Renderer*);
};
