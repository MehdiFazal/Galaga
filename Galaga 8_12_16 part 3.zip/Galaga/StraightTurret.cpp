#include"StraightTurret.h"

StraightTurret::StraightTurret(LTexture* image, float x, float y, int frame):Turret(image, x, y, frame)
{
    spriteSheetTexture = image;

    //Frame 0
    spriteClips[ 0 ].x = 190;
    spriteClips[ 0 ].y = 280;
    spriteClips[ 0 ].w = 12;
    spriteClips[ 0 ].h = 12;

    this->x = x;
    this->y = y;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;

}

StraightTurret::~StraightTurret()
{

}

void StraightTurret::Move(float y)
{
    this->y = y;
}

void StraightTurret::Render(long int& frame, SDL_Renderer* gRenderer)
{
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[frame % 1], 0.0, NULL, SDL_FLIP_VERTICAL, gRenderer );
}

