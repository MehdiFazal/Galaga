#pragma once
#include<math.h>
#include<cmath>
#include"PowerUP.h"

class HomingPU:public PowerUP
{
private:
    int EnemyNumber;
    enum ANIMATION_FRAMES {FLYING_FRAMES = 1};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
public:
    HomingPU(LTexture* image, float x, float y,int frame);
    ~HomingPU();
    void Move(int SCREEN_HEIGHT);
    void Move();
    void MoveL(int direction);
    void Render(long int& frame, SDL_Renderer* gRenderer);
};
