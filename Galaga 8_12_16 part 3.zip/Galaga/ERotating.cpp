#include"ERotating.h"


ERotating::~ERotating()
{
    spriteSheetTexture = NULL;
    cout<<"Enemy Deallocated"<<endl;
    delete ObjRectangle;
    ObjRectangle = NULL;
}

ERotating::ERotating(LTexture* image, float x, float y,int frame):ETurret(image, x, y, frame)
{
    Type = "ERotating";
    ObjRectangle = new SDL_Rect;
    rotation = 0.0;
    health = 1000000;
    friction = 0.85f;

    spriteClips[ 0 ].x = 217;
    spriteClips[ 0 ].y = 280;
    spriteClips[ 0 ].w = 11;
    spriteClips[ 0 ].h = 11;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
    ObjRectangle->x = x;
    ObjRectangle->y = y;
    ObjRectangle->h = height;
    ObjRectangle->w = width;
}


void ERotating::Move(int y)
{

    ObjTime ++;
    if (target != NULL)
    {
        this->y = y;
        int perp = target->getX() - this->x;
        int base = this->y - target->getY();
        if (base != 0)
        {
            rotation = atan2(perp,base) * (180 / 3.14159265) + 180;
        }
        else
        {
            rotation = 90.0;
        }
    }


}

void ERotating::MoveL(int direction)
{

}

void ERotating::Move()
{

}

void ERotating::Render(long int& frame, SDL_Renderer* gRenderer)
{
    ObjRectangle->x = x;
    ObjRectangle->y = y;
    spriteSheetTexture->Render( x , y , &spriteClips[ 0], rotation, NULL, SDL_FLIP_VERTICAL, gRenderer );

}

