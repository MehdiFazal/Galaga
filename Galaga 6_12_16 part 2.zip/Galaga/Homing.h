#pragma once

#include"Missile.h"

class Homing : public Missile
{
private:
    float angle;
    enum ANIMATION_FRAMES {FLYING_FRAMES = 3};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
public:
    Homing(LTexture* image, float x, float y, float angle);
    virtual ~Homing();
    virtual void Move(int);
    virtual void Render(long int& frame, SDL_Renderer* gRenderer);
};
