#pragma once
#include"Unit.h"

class Enemy: public Unit
{
protected:
    bool FireON;
public:
    Enemy(LTexture* image, float x, float y,int frame);
    ~Enemy();
    Unit* Fire();



};
