#pragma once

#include"Bullet.h"

class Missile : public Bullet
{
private:
    enum ANIMATION_FRAMES {FLYING_FRAMES = 3};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
public:
    Missile(LTexture* image, float x, float y, float angle);
    virtual ~Missile();
    virtual void Move(int);
    virtual void Render(long int& frame, SDL_Renderer* gRenderer);
};

// 362 ,238
//
// y =256
