#pragma once

#include"Bullet.h"

class MachineGun : public Bullet
{
private:
    enum ANIMATION_FRAMES {FLYING_FRAMES = 1};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
public:
    MachineGun(LTexture* image, float x, float y, float angle);
    virtual ~MachineGun();
    virtual void Move(int);
    virtual void Render(long int& frame, SDL_Renderer* gRenderer);
};
