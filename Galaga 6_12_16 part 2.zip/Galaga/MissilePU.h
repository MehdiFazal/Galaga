#pragma once
#include<math.h>
#include<cmath>
#include"PowerUP.h"

class MissilePU:public PowerUP
{
private:
    int EnemyNumber;
    enum ANIMATION_FRAMES {FLYING_FRAMES = 1};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
public:
    MissilePU(LTexture* image, float x, float y,int frame);
    ~MissilePU();
    void Move(int SCREEN_HEIGHT);
    void Move();
    void MoveL(int direction);
    void Render(long int& frame, SDL_Renderer* gRenderer);
};
