#pragma once
#include"Unit.h"

class Bullet: public Unit
{
public:
    Bullet(LTexture* image, float x, float y,int frame);
    ~Bullet();
    //void Move(int);
};

