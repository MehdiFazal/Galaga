#include "Missile.h"
#include "cmath"
#include "math.h"



Missile::~Missile()
{
    cout<<"MachineGun Deallocated"<<endl;
}

Missile::Missile(LTexture* image, float x, float y, float angle):Bullet(image, x, y, angle)
{
    health = -1;
    spriteSheetTexture = image;
    rotation = angle;
    spriteClips[ 0 ].x = 360;
    spriteClips[ 0 ].y = 239;
    spriteClips[ 0 ].w = 10;
    spriteClips[ 0 ].h = 16;

    spriteClips[ 1 ].x = 370;
    spriteClips[ 1 ].y = 239;
    spriteClips[ 1 ].w = 10;
    spriteClips[ 1 ].h = 16;

    spriteClips[ 2 ].x = 380;
    spriteClips[ 2 ].y = 239;
    spriteClips[ 2 ].w = 10;
    spriteClips[ 2 ].h = 16;


    this->x = x;
    this->y = y;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;

    alive  = true;
    speedx = 10*sin(rotation*3.1416/180);
    speedy = 10*cos(rotation*3.1416/180);

    //rotation = 360
    //speed


}

void Missile::Move(int SCREEN_HEIGHT)
{
    if (y <0 || y>SCREEN_HEIGHT+30 )
    {
        SetAlive(false);
    }

    y+=speedy;
    x+=speedx;
}

void Missile::Render(long int& frame, SDL_Renderer* gRenderer)
{
    if (health == 0)
    {
        this->alive = false;
    }
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame/10 % 3 ], 180-rotation, NULL, SDL_FLIP_NONE, gRenderer );
}
