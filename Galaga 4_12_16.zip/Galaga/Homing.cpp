#include "Missile.h"
#include "cmath"
#include "math.h"
#include "Homing.h"



Homing::~Homing()
{
    cout<<"MachineGun Deallocated"<<endl;
}

Homing::Homing(LTexture* image, float x, float y, float angle):Missile(image, x, y, angle)
{

    speedx = 10*sin(rotation*3.1416/180);
    speedy = 10*cos(rotation*3.1416/180);

    //rotation = 360
    //speed


}

void Homing::Move(int SCREEN_HEIGHT)
{
    if (y <0 || y>SCREEN_HEIGHT+30 )
    {
        SetAlive(false);
    }

    y+=speedy;
    x+=speedx;
}

void Homing::Render(long int& frame, SDL_Renderer* gRenderer)
{
    if (health == 0)
    {
        this->alive = false;
    }
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame/10 % 3 ], 180-rotation, NULL, SDL_FLIP_NONE, gRenderer );
}
