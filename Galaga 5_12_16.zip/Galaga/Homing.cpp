#include "Missile.h"
#include "cmath"
#include "math.h"
#include "Homing.h"



Homing::~Homing()
{
    cout<<"MachineGun Deallocated"<<endl;
}

Homing::Homing(LTexture* image, float x, float y, float angle):Missile(image, x, y, angle)
{
    health = -1;
    spriteSheetTexture = image;
    spriteClips[ 0 ].x = 360;
    spriteClips[ 0 ].y = 239;
    spriteClips[ 0 ].w = 10;
    spriteClips[ 0 ].h = 16;

    spriteClips[ 1 ].x = 370;
    spriteClips[ 1 ].y = 239;
    spriteClips[ 1 ].w = 10;
    spriteClips[ 1 ].h = 16;

    spriteClips[ 2 ].x = 380;
    spriteClips[ 2 ].y = 239;
    spriteClips[ 2 ].w = 10;
    spriteClips[ 2 ].h = 16;


    this->x = x;
    this->y = y;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;

    alive  = true;
    rotation = 0.0;
    ChangeInX = x;

    speedx = 0.0;
    speedy = 5.0;


}

void Homing::Move(int SCREEN_HEIGHT)
{
    if (y <0 || y>SCREEN_HEIGHT+30 )
    {
        SetAlive(false);
    }
    if (x <-30 || x>1024+30 )
    {
        SetAlive(false);
    }

    if (y<target->getY())
    {
        float Difference = sqrt(pow(x-target->getX(),2) + pow(y-target->getY(),2));
        if (target->getX()>x)
        {
            rotation = 90-  180*atan((y-target->getY())/(x-target->getX()))/3.1416 ;
        }
        else
        {
            rotation =270-  180*atan((y-target->getY())/(x-target->getX()))/3.1416 ;
        }
        speedx = 5*sin(rotation*3.1416/180);
        speedy = 5*cos(rotation*3.1416/180);
    }

    y+=speedy;
    x+=speedx;


}

void Homing::Render(long int& frame, SDL_Renderer* gRenderer)
{
    if (health == 0)
    {
        this->alive = false;
    }
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame/5 % 3 ], 180-rotation, NULL, SDL_FLIP_NONE, gRenderer );
}
