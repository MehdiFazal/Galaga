#include"Queue.h"
#include<iostream>
#include"ExplosionE.h"
#include"Bullet.h"
#include"Player.h"
#include"SDL.h"
#include"Unit.h"


using namespace std;

Queue::Queue()
{
    head = NULL;
    tail = NULL;
}

Queue::~Queue()
{
    while(head != NULL)
    {
        Node* temp = head;
        head = head->next;
        cout<<"Deallocating value: "<<temp->unit<<endl;
        delete temp;
    }
}

void Queue::Enqueue(Unit* unit)
{
    if(head == NULL)
    {
        head = new Node;
        head->unit = unit;
        head->next = NULL;
        head->prev = NULL;
        tail = head;
        printf("head allocated");
    }
    else
    {
        tail->next = new Node;
        tail->next->unit = unit;
        tail->next->next = NULL;
        tail->next->prev = tail;
        tail = tail->next;
        printf("enemy allocated");
    }

}


void Queue::collision(LTexture* Texture, Player* plane)
{
    Node* temp = head;
    Node* temp2 = NULL;
    while(temp != NULL)
    {
        temp2 = head;
        while (temp2 != NULL)
        {
            if (SDL_HasIntersection(temp->unit->GetRect(), temp2->unit->GetRect()) == SDL_TRUE)
            {
                if ((temp->unit->GetType() == "PMachineGun") && ((temp2->unit->GetType() == "Hunter") || (temp2->unit->GetType() == "OneHit") || (temp2->unit->GetType() == "TwoHit")))
                {
                    temp2->unit->HealthLost();
                    temp->unit->HealthLost();
                    if (temp2->unit->getHealth()==0)
                    {
                        ExplosionE* explode = new ExplosionE(Texture, temp2->unit->getX()-10, temp2->unit->getY()-10, 0.0);
                        this->Enqueue(explode);
                    }
                }
                else if ((temp->unit->GetType() == "PMachineGun") && (temp2->unit->GetType() == "EMachineGun"))
                {
                    temp2->unit->HealthLost();
                    temp->unit->HealthLost();
                    if (temp2->unit->getHealth()==0)
                    {
                        ExplosionE* explode = new ExplosionE(Texture, temp2->unit->getX()-10, temp2->unit->getY()-10, 0.0);
                        this->Enqueue(explode);
                    }
                }
            }
            if (temp->unit->getHealth() == 0)
            {
                temp->unit->SetAlive(false);
            }
            if (temp2->unit->getHealth() == 0)
            {
                temp2->unit->SetAlive(false);
            }
            temp2 = temp2->next;
        }
        temp = temp->next;
    }

}


void Queue::update(long int& frame, SDL_Renderer* gRenderer)
{

    Node* temp = head;
    while (temp != NULL)
    {
        if (temp->unit->GetAlive() == false)
        {
//            CleanBreakout(temp);
            Node* temp2 = temp;
            temp = temp->next;
            if (temp2->prev != NULL)
            {
                temp2->prev->next = temp2->next;
            }
            else
            {
                head = temp;
            }
            if (temp2->next != NULL)
            {
                temp2->next->prev = temp2->prev;
            }
            else
            {
                tail = temp2->prev;
            }
            delete temp2;
            temp2 = NULL;
        }
        else
        {
            temp->unit->Render(frame, gRenderer);
            if (temp->unit->GetType() == "Hunter")
            {
                Unit* BulletPointer = temp->unit->Fire();
                if (BulletPointer != NULL)
                {
                    std::cout<<BulletPointer;
                    this->Enqueue(BulletPointer);
                }
                BulletPointer = NULL;
            }
            temp->unit->Move(768);
            temp=temp->next;
        }



    }
}
