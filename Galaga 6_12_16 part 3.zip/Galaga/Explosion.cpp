#include"Explosion.h"

Explosion::Explosion(LTexture* image, float x, float y,int frame):Unit(image, x, y, frame)
{

}
Explosion::~Explosion()
{
    spriteSheetTexture = NULL;
    cout<<"Explosion Deallocated"<<endl;
}
