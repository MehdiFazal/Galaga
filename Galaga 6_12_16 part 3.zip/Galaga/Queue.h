#pragma once
#include"Node.h"
#include"Player.h"

class Queue
{
private:
    Node* head;
    Node* tail;
public:
    Queue();
    ~Queue();
    void Enqueue(Unit*);
    void collision(LTexture* Texture, Player* plane);

    //void Firedodge(int,int);
    //void FireClean();
    //void CleanBreakout(Node*);
    void update(long int& frame, SDL_Renderer* gRenderer);
    //void Render();
    //void Move(int);
};
