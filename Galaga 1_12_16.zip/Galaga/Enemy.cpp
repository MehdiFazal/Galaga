#include"Enemy.h"


Enemy::Enemy(LTexture* image, float x, float y,int frame):Unit(image, x, y, frame)
{
    Type = "EPlane";

}
Enemy::~Enemy()
{

}
