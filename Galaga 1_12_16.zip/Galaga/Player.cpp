#include"Player.h"

Player::Player(LTexture* image, float x, float y,int frame):Unit(image,x,y,frame)
{
    //Frame 0
    spriteClips[ 0 ].x = 156.5;
    spriteClips[ 0 ].y = 50;
    spriteClips[ 0 ].w = 24.25;
    spriteClips[ 0 ].h = 24.25;

    //Frame 1
    spriteClips[ 1 ].x = 180.75;
    spriteClips[ 1 ].y = 50;
    spriteClips[ 1 ].w = 24.25;
    spriteClips[ 1 ].h = 24.25;
    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
}


Player::~Player()
{

}

void Player::Move()
{
     speedx = speedx * friction;
     speedy = speedy * friction;

     x = x + speedx;
     y = y + speedy;
}

void Player::Move(int direction)
{

    if(direction==LEFT)
    {
        speedx = -5;
        x+=speedx;
    }

    if(direction==RIGHT)
    {
        speedx = 5;
        x+=speedx;
    }

    if(direction==UP)
    {
        speedy = -5;
        y+=speedy;
    }

    if(direction==DOWN)
    {
        speedy = 5;
        y+=speedy;
    }

}

void Player::Render(long int& frame, SDL_Renderer* gRenderer)
{
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
}
