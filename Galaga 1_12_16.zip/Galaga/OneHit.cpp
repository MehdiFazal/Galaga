#include"OneHit.h"
#include"PowerUP.h"
#include"MissilePU.h"


OneHit::~OneHit()
{
    spriteSheetTexture = NULL;
    cout<<"Enemy Deallocated"<<endl;
}

OneHit::OneHit(LTexture* image, float x, float y,int frame):Enemy(image, x, y, frame) //here float x represents the row, float y represents the column for the enemy
{
    ChangeInX = x;
    Row = x;                    // only an integer between 0 and 10
    Column = y;                 // only an integer between 0 and 4
    rotation = 180.0;
    health = 1;
    friction = 0.85f;
    //Frame 0
    spriteClips[ 0 ].x = 156.5;
    spriteClips[ 0 ].y = 98.5;
    spriteClips[ 0 ].w = 24.25;
    spriteClips[ 0 ].h = 24.25;

    //Frame 1
    spriteClips[ 1 ].x = 180.75;
    spriteClips[ 1 ].y = 98.5;
    spriteClips[ 1 ].w = 24.25;
    spriteClips[ 1 ].h = 24.25;
    EnemyNumber = frame;
    if (Column <= 7)
    {
        this->x = -10;
    }
    if (Column > 7)
    {
        this->x = 1000;
    }

    this->y = -25;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;

}


void OneHit::Move(int SCREEN_HEIGHT)
{
//    ObjTime ++;
//    if (y > SCREEN_HEIGHT+96)
//    {
//        SetAlive(false);
//    }
//    if (ObjTime <= 80)
//    {
//        x += 0.35 ;
//        y += (sqrt(8*ObjTime)/5);
//    }
//    if (ObjTime > 80 && ObjTime <= 250)
//    {
//        x += 1+ (Column/3.5);
//        y += 5*(sin((ObjTime +30 )*3.14/(180)));
//    }

//----------------------------------------------------//

//    ObjTime ++;
//    if (y > SCREEN_HEIGHT+96)
//    {
//        SetAlive(false);
//    }
//    if (ObjTime <= 15)
//    {
//        x+= exp((ObjTime-34)/10.0);
//        //x += 0.45;
//        //y += 12*(sin((ObjTime)*3.14/(180)));
//        y += 4*(sqrt(8*ObjTime)/5) + 25  ;
//    }
//    if (ObjTime > 15 && ObjTime <= 150)
//    {
//        x += 2.35+ (Column/1.0);// - (Row/5.0);
//        y += 25*(sin((ObjTime+190)*3.14/(180))) + (Row) +25;
//    }


//-----------------------------------------------------//



   ObjTime ++;
    if (y > SCREEN_HEIGHT+96)
    {
        SetAlive(false);
    }
    if (ObjTime <= 50)
    {
        if (Column >7)
        {
            x-= exp((ObjTime-34)/10.0);
        }
        else if (Column <=7)
        {
            x+= exp((ObjTime-34)/10.0);
        }
        y += 4*(sqrt(8*ObjTime)/5) ;
    }

    if (ObjTime > 50 && ObjTime <= 95)
    {
        if (Column >7)
        {
            x -= 1.9+ ((Column-7.0)/1.0);
        }
        else if (Column <=7)
        {
            x += 2.30+ (Column/1.0);
        }

        y += 25*(sin((ObjTime+130)*3.14/(180))) + (Row);
    }
    if (ObjTime>= 2300 - 600*(Row))
    {
        if (Column >7)
        {
            x-= (10*cos(ObjTime/5));
        }
        else if (Column <=7)
        {
            x+= (10*cos(ObjTime/5));
        }

        y+= 10;
        //y+= (10*sin(ObjTime/50));
    }
    rotation = 180 +3.0*(x-ChangeInX+1);
    ChangeInX = x;

//-----------------------------------------------------//


 // -------The only working code-------//
//   ObjTime ++;
//    if (y > SCREEN_HEIGHT+96)
//    {
//        SetAlive(false);
//    }
//    if (ObjTime <= 50)
//    {
//        x+= exp((ObjTime-34)/10.0);
//        //x += 0.45;
//        //y += 12*(sin((ObjTime)*3.14/(180)));
//        y += 4*(sqrt(8*ObjTime)/5) ;
//    }
//    if (ObjTime == 50)
//    {
//        std::cout<<endl<<"-------------------"<<x<<"---------------"<<endl;
//    }
//    if (ObjTime > 50 && ObjTime <= 95)
//    {
//        x += 2.30+ (Column/1.0);// - (Row/5.0);
//        y += 25*(sin((ObjTime+130)*3.14/(180))) + (Row);
//    }
//    if (ObjTime == 130)
//    {
//        std::cout<<endl<<"-------------------"<<x<<"---------------"<<endl;
//    }

//-----------------------------------------------------------------------//

    //EnemyTicks ++;
//    if (y > SCREEN_HEIGHT+96)
//    {
//        SetAlive(false);
//    }
//    //speedy = 5;
//    //y+=speedy;
//    //x+= ((2*sin(0.05*EnemyTicks))*2);
//    if (ObjTime<100) // value 280 works
//    {
//    //x+= 0;
//    //y+= EnemyTicks;
//
//    x+= 1 ; //(10*cos(EnemyTicks/5));
//    y+= (x*x)/1000;//(10*sin(EnemyTicks/50));
//    //y+= (5*cos(EnemyTicks/50));
////    y+= -(sqrt((1-(pow(x,2))*pow(3,2))))+35;
//    }
//    if (ObjTime>500 && ObjTime<300) // value 280 works
//    {
//    //x+= 0;
//    //y+= EnemyTicks;
//
//    x+= 1 ;//(10*cos(EnemyTicks/5));
//    y-= (x*x)/1000;//(10*sin(EnemyTicks/50));
//    //y+= (5*cos(EnemyTicks/50));
////    y+= -(sqrt((1-(pow(x,2))*pow(3,2))))+35;
//    }
//    if (ObjTime>=300)
//    {
//
//    x+= (10*cos(ObjTime/5));   //Jackpot     x+= (10*cos(ObjTime/5));
//    y+= (10*sin(ObjTime/50))-1;   //Jackpot    y+= (10*sin(ObjTime/50));
//    }


}

void OneHit::MoveL(int direction)
{

    if(direction==2) //Left
    {
        speedx = -5;
        //x+=speedx;
    }

    if(direction==3) //Right
    {
        speedx = 5;
        //x+=speedx;
    }

}

void OneHit::Move()
{
    speedx = speedx * friction;
    //x = x + speedx;
}


void OneHit::Render(long int& frame, SDL_Renderer* gRenderer)
{
    if (health == 0)
    {
        this->alive = false;

    }
    spriteSheetTexture->Render( x - width/2 , y - height/2, &spriteClips[ frame/10 % 2], rotation, NULL, SDL_FLIP_NONE, gRenderer );

}

