#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include"LTexture.h"

using namespace std;


enum MOTION {RIGHT, LEFT, UP, DOWN};

class Unit
{
    protected:
        bool alive;
        float x;
        float y;
        float speedx;
        float speedy;
        int width;
        int height;
        float rotation;
        float friction; //lower speed means more friction
        bool IfBullet;
        int health;
        float ChangeInX;
        float ChangeInY;
        string Type;
        int SpriteNumber;
        long int ObjTime;
        //enum ANIMATION_FRAMES {FLYING_FRAMES = 2};
        //SDL_Rect spriteClips[ FLYING_FRAMES ];
        LTexture* spriteSheetTexture;
        Unit* target;

    public:
        Unit();
        Unit(LTexture* image, float x, float y, int frame);
        virtual ~Unit();
        void SetAlive(bool);
        bool GetAlive();
        bool GetIfBullet();
        int getHealth();
        void SetHealth(int);
        void HealthLost();
        void SetTarget(Unit*);
        Unit* GetTarget();
        string GetType();
        float getX();
        float getY();
        virtual void MoveL(int direction);
        virtual void Move(int direction) = 0;
        virtual void Move();
        virtual void Render(long int& frame, SDL_Renderer* gRenderer);
};



