#include"PowerUP.h"

PowerUP::PowerUP(LTexture* image, float x, float y,int frame):Unit(image, x, y, frame)
{
    Type = "PU";

}
PowerUP::~PowerUP()
{
    spriteSheetTexture = NULL;
    cout<<"PowerUP Deallocated"<<endl;
}
