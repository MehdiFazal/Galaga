#include"Hunter.h"
#include"MissilePU.h"



Hunter::~Hunter()
{
    spriteSheetTexture = NULL;
    cout<<"Enemy Deallocated"<<endl;
}

Hunter::Hunter(LTexture* image, float x, float y,int frame):Enemy(image, x, y, frame)
{
    ChangeInX = x;
    Row = x;                    // only an integer between 0 and 10
    Column = y;                 // only an integer between 0 and 4

    rotation = 180.0;
    health = 2;
    friction = 0.85f;
    //Frame 0
    spriteClips[ 0 ].x = 156.0;
    spriteClips[ 0 ].y = 315.0;
    spriteClips[ 0 ].w = 22.0;
    spriteClips[ 0 ].h = 24.0;

    //Frame 1
    spriteClips[ 1 ].x = 178.0;
    spriteClips[ 1 ].y = 315.0;
    spriteClips[ 1 ].w = 22.0;
    spriteClips[ 1 ].h = 24.0;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
    //EnemyNumber = (frame%8);
        if (Column <= 7)
    {
        this->x = -10;
    }
    if (Column > 7)
    {
        this->x = 1000;
    }

    this->y = -25;
    //ObjTime = 800.0;

}


void Hunter::Move(int SCREEN_HEIGHT)
{
    ObjTime ++;
//-----------------------------------------------------------------------//
    if (y > SCREEN_HEIGHT+96)
    {
        SetAlive(false);
    }
//-----------------------------------------------------------------------//

    if (ObjTime <= 50)
    {
        if (Column >7)
        {
            x-= exp((ObjTime-34)/10.0);
        }
        else if (Column <=7)
        {
            x+= exp((ObjTime-34)/10.0);
        }
        y += 4*(sqrt(8*ObjTime)/5) ;

    }
//-----------------------------------------------------------------------//

    if (ObjTime > 50 && ObjTime <= 95)
    {
        if (Column >7)
        {
            x -= 1.9+ ((Column-7.0)/1.0);
        }
        else if (Column <=7)
        {
            x += 2.30+ (Column/1.0);
        }

        y += 25*(sin((ObjTime+130)*3.14/(180))) + (Row);

    }
//-----------------------------------------------------------------------//
    if (ObjTime< 1000 - 150*(Row) + 50*(Column%8))
    {
        rotation =  - 3.0*(x-ChangeInX+1) ;
        ChangeInX = x;
    }

//-----------------------------------------------------------------------//


    if (ObjTime>= 1000 - 150*(Row) + 50*(Column%8))
    {
        if (ObjTime < 1000 - 150*(Row) + 50*(Column%8)+70)
        {
            ConsTargetX = target->getX();
            ConsTargetY = target->getY();
            if (ObjTime%10 == 0)
            {
                FireON = true;
            }
            else
            {
                FireON = false;
            }
        }
        if (y<ConsTargetY)
        {
            if (ConsTargetX>x)
            {
                rotation = 90-  180*atan((y-ConsTargetY)/(x-ConsTargetX))/3.1416 ;
            }
            else
            {
                rotation =270-  180*atan((y-ConsTargetY)/(x-ConsTargetX))/3.1416 ;
            }
            speedx = 4.5*sin(rotation*3.1416/180);
            speedy = 2*cos(rotation*3.1416/180);
        }
        if (ObjTime > 1000 - 150*(Row) + 50*(Column%8) +200 )
        {
            speedx =0 ;
            speedy = 0;
//            if (speedx > 0)
//            {
//                speedx -= 0.001;
//            }
//            else if (speedx <0)
//            {
//                speedx = 0;
//            }
//            if (speedy > 4)
//            {
//                speedy -= 0.1;
//            }
//            else if (speedy <4)
//            {
//                speedy = 4;
//            }
//            rotation = 3.0*(x-ChangeInX+1);
//            ChangeInX = x;
        }

        y+=speedy;
        x+=speedx;


        //y+= (10*sin(ObjTime/50));
    }
//-----------------------------------------------------------------------//

   // rotation = 180 +3.0*(x-ChangeInX+1);
   // ChangeInX = x;
//-----------------------------------------------------------------------//

//    ObjTime ++;
//    if (y > SCREEN_HEIGHT+96)
//    {
//        SetAlive(false);
//    }
//    if (ObjTime <= 30)
//    {
//        x += 1 ;
//        y += sqrt(4*2*ObjTime)/5;
//    }
//    if (ObjTime > 30 && ObjTime <=  300)
//    {
//        x += 1 + EnemyNumber ;
//        y += 4*(sin(ObjTime*3.14/(180)));
//    }
//---------------------------------------------//
//    if (ObjTime<50) // value 280 works
//    {
//    x+= 1;
//    y+= (x*x)/10000;
//    }
//    if (ObjTime>500 && ObjTime<300) // value 280 works
//    {
//    x+= 1;
//    y-= (x*x)/1000;
//    }
//    if (ObjTime>=300)
//    {
//    x+= (10*cos(ObjTime/5));
//    y+= (10*sin(ObjTime/50));
//    }

}

void Hunter::MoveL(int direction)
{

    if(direction==2) //Left
    {
        //speedx = -5;
        //x+=speedx;
    }

    if(direction==3) //Right
    {
        //speedx = 5;
        //x+=speedx;
    }

}

void Hunter::Move()
{
    //speedx = speedx * friction;
    //x = x + speedx;
}


void Hunter::Render(long int& frame, SDL_Renderer* gRenderer)
{
    if (health == 0)
    {
        this->alive = false;

    }

    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame/10 % 2 ], 180-rotation, NULL, SDL_FLIP_NONE, gRenderer );

}




