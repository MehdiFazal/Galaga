#pragma once
#include<math.h>
#include<cmath>
#include"Enemy.h"

class Hunter:public Enemy
{
private:
    int Row;
    int Column;
    float ConsTargetX;
    float ConsTargetY;
    enum ANIMATION_FRAMES {FLYING_FRAMES = 2};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
public:
    Hunter(LTexture* image, float x, float y,int frame);
    ~Hunter();
    void Move(int SCREEN_HEIGHT);
    void Move();
    void MoveL(int direction);
    void Render(long int& frame, SDL_Renderer* gRenderer);
};
