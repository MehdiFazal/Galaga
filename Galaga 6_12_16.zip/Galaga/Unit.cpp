#include "Unit.h"
Unit::Unit()
{

}

void Unit::MoveL(int direction)
{

}

Unit::Unit(LTexture* image, float x, float y, int frame)
{
    health = 1;
    spriteSheetTexture = image;
    ObjTime = 0;
    SpriteNumber = 0;
    target = NULL;


    this->x = x;
    this->y = y;



    friction = 0.95f;
    speedx = 0;
    speedy = 0;
    alive  = true;
    IfBullet = false;
}


Unit::~Unit()
{
    spriteSheetTexture = NULL;
}

void Unit::SetAlive(bool alive)
{
    this->alive = alive;
}
bool Unit::GetIfBullet()
{
    return IfBullet;
}
bool Unit::GetAlive()
{
    return alive;
}

void Unit::Move(int direction)
{

}

float Unit::getX()
{
    return x;
}

float Unit::getY()
{
    return y;
}

void Unit::Move()
{

}

int Unit::getHealth()
{
    return health;
}

void Unit::SetHealth(int Hlth)
{
    health = Hlth;
}

void Unit::HealthLost()
{
    health-=1;
}
void Unit::Render(long int& frame, SDL_Renderer* gRenderer)
{
    //spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
}

void Unit::SetTarget(Unit* target)
{
    this->target = target;
}

Unit* Unit::GetTarget()
{
    return target;
}

Unit* Unit::Fire()
{
    return NULL;
}

string Unit::GetType()
{
    return Type;
}
