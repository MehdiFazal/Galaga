#pragma once
#include"Unit.h"

class Enemy: public Unit
{
public:
    Enemy(LTexture* image, float x, float y,int frame);
    ~Enemy();

};
