#pragma once

#pragma once
#include<math.h>
#include<cmath>
#include"Enemy.h"

class TwoHit:public Enemy
{
private:
    int EnemyNumber;
    enum ANIMATION_FRAMES {FLYING_FRAMES = 2};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
public:
    TwoHit(LTexture* image, float x, float y,int frame);
    ~TwoHit();
    void Move(int SCREEN_HEIGHT);
    void Move();
    void MoveL(int direction);
    void Render(long int& frame, SDL_Renderer* gRenderer);
};
