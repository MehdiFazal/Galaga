#include"TwoHit.h"
#include"MissilePU.h"



TwoHit::~TwoHit()
{
    spriteSheetTexture = NULL;
    cout<<"Enemy Deallocated"<<endl;
}

TwoHit::TwoHit(LTexture* image, float x, float y,int frame):Enemy(image, x, y, frame)
{

    rotation = 180.0;
    health = 2;
    friction = 0.85f;
    //Frame 0
    spriteClips[ 0 ].x = 156.5;
    spriteClips[ 0 ].y = 171.25;
    spriteClips[ 0 ].w = 24.25;
    spriteClips[ 0 ].h = 24.25;

    //Frame 1
    spriteClips[ 1 ].x = 180.75;
    spriteClips[ 1 ].y = 171.25;
    spriteClips[ 1 ].w = 24.25;
    spriteClips[ 1 ].h = 24.25;
    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
    EnemyNumber = frame;

}


void TwoHit::Move(int SCREEN_HEIGHT)
{
    ObjTime ++;
    if (y > SCREEN_HEIGHT+96)
    {
        SetAlive(false);
    }
    y+=10*sin(ObjTime/50);
//    if (ObjTime<50) // value 280 works
//    {
//    x+= 1;
//    y+= (x*x)/10000;
//    }
//    if (ObjTime>500 && ObjTime<300) // value 280 works
//    {
//    x+= 1;
//    y-= (x*x)/1000;
//    }
//    if (ObjTime>=300)
//    {
//    x+= (10*cos(ObjTime/5));
//    y+= (10*sin(ObjTime/50));
//    }

}

void TwoHit::MoveL(int direction)
{

    if(direction==2) //Left
    {
        speedx = -5;
        //x+=speedx;
    }

    if(direction==3) //Right
    {
        speedx = 5;
        //x+=speedx;
    }

}

void TwoHit::Move()
{
    speedx = speedx * friction;
    //x = x + speedx;
}


void TwoHit::Render(long int& frame, SDL_Renderer* gRenderer)
{
    if (health == 0)
    {
        this->alive = false;

    }
    if (frame%10 == 0)
    {
        if (SpriteNumber == 0)
        {
            SpriteNumber =1;
        }
        else
        {
            SpriteNumber = 0;
        }
    }
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ SpriteNumber ], rotation, NULL, SDL_FLIP_NONE, gRenderer );

}

