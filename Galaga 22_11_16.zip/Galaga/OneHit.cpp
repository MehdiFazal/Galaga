#include"OneHit.h"
#include"PowerUP.h"
#include"MissilePU.h"


OneHit::~OneHit()
{
    spriteSheetTexture = NULL;
    cout<<"Enemy Deallocated"<<endl;
}

OneHit::OneHit(LTexture* image, float x, float y,int frame):Enemy(image, x, y, frame)
{
    ChangeInX = x;

    rotation = 180.0;
    health = 1;
    friction = 0.85f;
    //Frame 0
    spriteClips[ 0 ].x = 156.5;
    spriteClips[ 0 ].y = 98.5;
    spriteClips[ 0 ].w = 24.25;
    spriteClips[ 0 ].h = 24.25;

    //Frame 1
    spriteClips[ 1 ].x = 180.75;
    spriteClips[ 1 ].y = 98.5;
    spriteClips[ 1 ].w = 24.25;
    spriteClips[ 1 ].h = 24.25;
    EnemyNumber = frame;
    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;

}


void OneHit::Move(int SCREEN_HEIGHT)
{
    ObjTime ++;

    //EnemyTicks ++;
    if (y > SCREEN_HEIGHT+96)
    {
        SetAlive(false);
    }
    //speedy = 5;
    //y+=speedy;
    //x+= ((2*sin(0.05*EnemyTicks))*2);
    if (ObjTime<70) // value 280 works
    {
    //x+= 0;
    //y+= EnemyTicks;

    x+= 1 ; //(10*cos(EnemyTicks/5));
    y+= (x*x)/1000;//(10*sin(EnemyTicks/50));
    //y+= (5*cos(EnemyTicks/50));
//    y+= -(sqrt((1-(pow(x,2))*pow(3,2))))+35;
    }
    if (ObjTime>500 && ObjTime<300) // value 280 works
    {
    //x+= 0;
    //y+= EnemyTicks;

    x+= 1 ;//(10*cos(EnemyTicks/5));
    y-= (x*x)/1000;//(10*sin(EnemyTicks/50));
    //y+= (5*cos(EnemyTicks/50));
//    y+= -(sqrt((1-(pow(x,2))*pow(3,2))))+35;
    }
    if (ObjTime>=300)
    {

    x+= (10*cos(ObjTime/5));   //Jackpot     x+= (10*cos(ObjTime/5));
    y+= (10*sin(ObjTime/50))-1;   //Jackpot    y+= (10*sin(ObjTime/50));
    }
    rotation = 180 - 3*(x-ChangeInX+1);
    //rotation = 180 - 2*(x-ChangeInX);
    ChangeInX = x;

}

void OneHit::MoveL(int direction)
{

    if(direction==2) //Left
    {
        speedx = -5;
        //x+=speedx;
    }

    if(direction==3) //Right
    {
        speedx = 5;
        //x+=speedx;
    }

}

void OneHit::Move()
{
    speedx = speedx * friction;
    //x = x + speedx;
}


void OneHit::Render(long int& frame, SDL_Renderer* gRenderer)
{
    if (health == 0)
    {
        health =10000;
        MisPU = new MissilePU(spriteSheetTexture, x + 2*EnemyNumber, y, frame);
    }
    if (health>1)
    {
        spriteClips[ 0 ].x = 0;
        spriteClips[ 0 ].y = 0;
        spriteClips[ 0 ].w = 1;
        spriteClips[ 0 ].h = 1;
        spriteClips[ 1 ].x = 0;
        spriteClips[ 1 ].y = 0;
        spriteClips[ 1 ].w = 1;
        spriteClips[ 1 ].h = 1;

        MisPU->Render(frame,gRenderer);
        MisPU->Move(768);
    }


    if (frame%10 == 0)
    {
        if (SpriteNumber == 0)
        {
            SpriteNumber =1;
        }
        else
        {
            SpriteNumber = 0;
        }
    }

    spriteSheetTexture->Render( x - width/2 + 2*EnemyNumber, y - height/2, &spriteClips[ SpriteNumber ], rotation, NULL, SDL_FLIP_NONE, gRenderer );

}

