#pragma once
#include"Unit.h"


class Player:public Unit
{
public:
    enum ANIMATION_FRAMES {FLYING_FRAMES = 2};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
private:
    Player(LTexture* image, float x, float y,int frame);
    ~Player();
    void Move(int direction);
    void Move();
    void Render(long int& frame, SDL_Renderer* gRenderer);
};
