#pragma once

#include"Unit.h"

class PowerUP: public Unit
{
public:
    PowerUP(LTexture* image, float x, float y,int frame);
    ~PowerUP();

};
