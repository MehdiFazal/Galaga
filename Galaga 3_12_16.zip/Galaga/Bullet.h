#pragma once

#include"Unit.h"

class Bullet : public Unit
{
private:
    enum ANIMATION_FRAMES {FLYING_FRAMES = 1};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
    char typ;
public:
    Bullet(LTexture* image, float x, float y, char typ);
    virtual ~Bullet();
    virtual void Move(int);
    virtual void Render(long int& frame, SDL_Renderer* gRenderer);
};
