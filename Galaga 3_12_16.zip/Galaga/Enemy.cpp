#include"Enemy.h"
#include"Bullet.h"


Enemy::Enemy(LTexture* image, float x, float y,int frame):Unit(image, x, y, frame)
{
    Type = "EPlane";
    FireON = false;

}
Enemy::~Enemy()
{

}

Unit* Enemy::Fire()
{
    if (FireON == true)
    {
        Unit* B = new Bullet(spriteSheetTexture, x, y, 'E');
        return B;
    }
    else
    {
        return NULL;
    }
}

